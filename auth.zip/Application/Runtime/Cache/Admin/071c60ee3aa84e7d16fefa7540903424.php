<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>角色权限设置</title>
	<link rel="stylesheet" href="/test/auth/statics/bootstrap3/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/test/auth/statics/bootstrap3/css/bootstrap-theme.min.css" />	
	<link rel="stylesheet" href="/test/auth/statics/css/default.css" />
	<script src="/test/auth/statics/bootstrap3/js/jquery.min.js"></script>
	<script src="/test/auth/statics/bootstrap3/js/bootstrap.min.js"></script>
	
	<script type="text/javascript">
		$(document).ready(function(){			//
			$('#collapseTwo').addClass('in');
			$('#collapse1').addClass('in');
			$('#collapseOne').removeClass('in');
			$('#myTab a:first').tab('show');
			//全选或反选操作
			$(".moduleName").click(function(){
				var index=$(this).attr('index');
				//全选操作
				if(this.checked){
					//初始化len为空
					var len=0;
					//循环选择权限操作
					$("input[label='group"+index+"']").each(function(i){
						len++;					
						this.checked=true;
					});
					$(this).attr('len',len)
				//反选操作
				}else{
					$("input[label='group"+index+"']").removeProp("checked");
					$(this).attr("len",'0');
				}
			
			});

			//页面加载时运行时,显示对应角色的权限
			var ruleID="<?php echo ($ruleID[0]['rules']); ?>";
			var arr=ruleID.split(',');
			//循环判断,有权限就选择
			$("input[name='rule[]']").each(function(){	
				//判断是否在数组中		
				if($.inArray(this.value,arr)>=0){
					$(this).prop('checked','true');
					//获取当前label标签的最后一个数字,通过这个数字来获取相应的模块组
					var label=$(this).attr('label').charAt(5);
					//权限所在模块组
					var grp=$('input[index="'+label+'"]');
					//len属性默认为0,对len循环加1操作
					var len=parseInt(grp.attr('len'))+1;
					//改变len的值 
					grp.attr('len',len);
					//判断这模块组是否已经选择,如没有选择,则选上
					if(!grp.prop('checked')){
						grp.prop('checked','true');
					}
				}
			});

			//选择权限时,判断该权限所在的模块组是否选上
			$("input[name='rule[]']").click(function(){
				//获取当前label标签的最后一个数字,通过这个数字来获取相应的模块组
				var label=$(this).attr('label').charAt(5);
				//权限所在模块组
				var grp=$('input[index="'+label+'"]');
				//所在模块组已经选中的权限个数
				var len=parseInt(grp.attr('len'));
				if(this.checked){
					//每选中一次,执行自加操作	
					len++;
					grp.attr('len',len);
					if(!grp.prop('checked')){
						//判断这模块组是否已经选择,如没有选择,则选上
						grp.prop('checked','true');
					}					
				}else{
					//每取消一次,执行自减操作
					len--;
					grp.attr('len',len);
					//当被选择权限数为0时,移除模块组选择状态
					len<=0?grp.removeProp('checked'):'';				
				}				
			});

		});
	</script>

	<style type="text/css">
		body{
			padding-top: 70px;
		}
	</style>
</head>

<body>
	<!--nav导航条-->
	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">	
		<div class="container">
			<div class="collapse navbar-collapse">
			    <ul class="nav navbar-nav">
			      <li class="active"><a href="#">我的面板</a></li>
			      <li><a href="<?php echo U('Admin/Index/index');?>">首页</a></li>
			      <li><a href="#">设置</a></li>
			      <li><a href="#">模块</a></li>
			      <li><a href="#">内容</a></li>
			      <li><a href="#">用户</a></li>
			      <li><a href="#">界面</a></li>
			      <li><a href="#">扩展</a></li>
			    </ul>

			    <ul class="nav navbar-nav navbar-right">
			   		<li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" role="button" href="#"><i class="glyphicon glyphicon-user"></i> <?php echo (session('username')); ?> <i class="caret"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="#" tabindex="-1"><i class="glyphicon glyphicon-cog"></i>	设置</a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="<?php echo U('Admin/Login/logout');?>" tabindex="-1"><i class="glyphicon glyphicon-off"></i>	退出</a>
                            </li>
                        </ul>
                    </li>
			    </ul>
  			</div><!-- /.navbar-collapse -->
		</div>
	</nav>
	<!--/nav导航条-->
	<div class="container">
		<div class="row">
			
	<div id="sidebar" class="col-sm-3">
		<div class="panel-group" id="accordion">
			<div class="panel panel-primary">
			    <div class="panel-heading">
			     	<h4 class="panel-title">
			       		<a data-toggle="collapse" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><i class="glyphicon glyphicon-user"></i> 会 员 管 理</a>
			      	</h4>
			    </div>
			    <div id="collapseOne" class="panel-collapse collapse in">
				      	<div class="panel-body">
				         	<ul class=" nav nav-pills nav-stacked">
					          	<li><a href="<?php echo U('Admin/Member/memberList');?>">会员列表</a></li>
					      		<li><a href="<?php echo U('Admin/Member/memberAdd');?>">添加会员</a></li>
				      		</ul>
				     	 </div>
			    </div>
	  </div>
		<div class="panel panel-primary">
		    <div class="panel-heading">
		        <h4 class="panel-title">
			        <a data-toggle="collapse" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><i class="glyphicon glyphicon-list"></i> 权 限 管 理
			        </a>
		     	</h4>
		    </div>
		    <div id="collapseTwo" class="panel-collapse collapse">
		     	<div class="panel-body">
			      	<ul class=" nav nav-pills nav-stacked">
			          	<li><a href="<?php echo U('Admin/Auth/accessList');?>">权限列表</a></li>
			      		<li><a href="<?php echo U('Admin/Auth/accessAdd');?>">添加权限</a></li>
			      		<li><a href="<?php echo U('Admin/Auth/groupList');?>">角色管理</a></li>
			      	</ul>
		      	</div>
		    </div>
		  </div>
		</div>
	</div>	

			
	<div id="content" class="col-sm-8">
		<div class="panel panel-default">
			<div class="panel-heading">
					<h4 class="panel-title"><i class="glyphicon glyphicon-header"></i> 角色权限设置---<?php echo ($group['name']); ?></h4>
			</div>	
		<form class="form-inline" action="<?php echo U('Admin/Auth/accessSelectHandle');?>" method="post">
		<input type="hidden" name="groupID" value='<?php echo ($group["id"]); ?>' />
		<div class="panel-body">	
		<div class="panel-group" id="accordionRule">
			
			<?php if(is_array($result)): $i = 0; $__LIST__ = $result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="panel panel-primary">
				    <div class="panel-heading">
				     	<h4 class="panel-title">
				     	<label class="checkbox-inline">
				     		<input type='checkbox' class="moduleName" index="<?php echo ($i); ?>" len="0" />
				     		<span data-toggle="collapse" data-toggle="collapse" data-parent="#accordionRule" href="#collapse<?php echo ($i); ?>"><?php echo ($key); ?></span></label>
				      	</h4>
				    </div>
				    <div id="collapse<?php echo ($i); ?>" class="panel-collapse collapse">
					      	<div class="panel-body">
					         	<?php if(is_array($vo)): foreach($vo as $key=>$v): ?><label class="checkbox-inline">
					         			<input type='checkbox' name="rule[]" label="group<?php echo ($i); ?>" value="<?php echo ($v['id']); ?>" /> <?php echo ($v['title']); ?>
					         		</label><?php endforeach; endif; ?>
					     	</div>
				    </div>
		  		</div><?php endforeach; endif; else: echo "" ;endif; ?>		  	
		</div>
	</div>

	<div class="panel-footer">
		<div class="form-group">		
				<button type="submit" class="btn btn-success btn-add">更新</button>
		</div>
	</div>

	</form>
	</div>
</div>

		</div>
	</div>


</body>
</html>