<?php
namespace Admin\Controller;
use Admin\Controller\AdminController;
//use Think\Controller;
class IndexController extends AdminController {
    public function index(){
       $this->display();
    }

   
    

}